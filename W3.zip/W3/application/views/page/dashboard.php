<h1>Welcome to Dashboard</h1>
<p>Only logged-in users can see this page.</p>
<a href="<?php echo base_url(); ?>">Logout</a>